# CelularRank — IA de Preços

Projeto separado do site CelularRank. A função deste serviço é pesquisar, validar e atualizar **somente preços**.

## Fontes previstas

- Mercado Livre
- Amazon
- Shopee
- Lojas oficiais

## Regra principal

A IA/serviço nunca deve inventar preço. Se não houver preço confiável, o preço anterior permanece.

## Importante

Este projeto é um backend. Não coloque chaves de API no GitHub Pages nem em arquivos JavaScript públicos do site.

## Instalação

1. Instale Node.js 20 ou superior.
2. Abra um terminal dentro desta pasta.
3. Execute `npm install`.
4. Copie `.env.example` para `.env`.
5. Execute `npm start`.
6. Para atualizar manualmente, use `npm run update`.

## Estado atual

O adaptador do Mercado Livre já está preparado para consulta de busca. Os adaptadores de Amazon, Shopee e lojas oficiais ficam isolados e retornam vazio até serem ligados às integrações permitidas e às credenciais necessárias. Isso é intencional: o sistema não cria preços falsos nem faz scraping escondido.
