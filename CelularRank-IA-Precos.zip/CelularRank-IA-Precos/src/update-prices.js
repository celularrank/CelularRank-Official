import 'dotenv/config';
import fs from 'node:fs/promises';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { coletarPrecos, escolherPreco } from './price-engine.js';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const DATA_FILE = path.join(__dirname, '..', 'data', 'products.json');

async function carregarProdutos() {
  return JSON.parse(await fs.readFile(DATA_FILE, 'utf8'));
}

async function salvarProdutos(produtos) {
  await fs.writeFile(DATA_FILE, `${JSON.stringify(produtos, null, 2)}\n`, 'utf8');
}

export async function atualizarPrecos() {
  const produtos = await carregarProdutos();
  const agora = new Date().toISOString();

  for (const produto of produtos) {
    console.log(`\n🔎 ${produto.nome}`);
    const candidatos = await coletarPrecos(produto);
    const resultado = escolherPreco(candidatos);

    if (resultado.aprovado) {
      produto.precoAtual = resultado.preco;
      produto.ultimaAtualizacao = agora;
      produto.precoFonte = resultado.fontePrincipal;
      produto.precosEncontrados = resultado.candidatos;
      console.log(`✅ R$ ${resultado.preco.toFixed(2)} — ${resultado.fontePrincipal}`);
    } else {
      // Regra principal: nunca apagar/substituir um preço existente por falta de resultado.
      produto.precosEncontrados = candidatos;
      console.log(`⏸️ Mantido preço anterior — ${resultado.motivo}`);
    }
  }

  await salvarProdutos(produtos);
  return produtos;
}

if (process.argv[1] === fileURLToPath(import.meta.url)) {
  atualizarPrecos().catch(erro => {
    console.error('❌ Falha na atualização:', erro);
    process.exitCode = 1;
  });
}
