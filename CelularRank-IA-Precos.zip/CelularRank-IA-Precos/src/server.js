import 'dotenv/config';
import express from 'express';
import fs from 'node:fs/promises';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { atualizarPrecos } from './update-prices.js';

const app = express();
const PORT = Number(process.env.PORT || 3000);
const __dirname = path.dirname(fileURLToPath(import.meta.url));
const DATA_FILE = path.join(__dirname, '..', 'data', 'products.json');

app.use(express.json());

app.get('/health', (_req, res) => {
  res.json({ ok: true, servico: 'CelularRank IA de Preços' });
});

app.get('/api/precos', async (_req, res) => {
  try {
    const produtos = JSON.parse(await fs.readFile(DATA_FILE, 'utf8'));
    res.json({ ok: true, produtos });
  } catch (erro) {
    res.status(500).json({ ok: false, erro: erro.message });
  }
});

app.post('/api/atualizar', async (_req, res) => {
  try {
    const produtos = await atualizarPrecos();
    res.json({ ok: true, mensagem: 'Atualização concluída.', produtos });
  } catch (erro) {
    res.status(500).json({ ok: false, erro: erro.message });
  }
});

app.listen(PORT, () => {
  console.log(`🚀 CelularRank IA de Preços rodando em http://localhost:${PORT}`);
});
