import { buscarMercadoLivre } from './sources/mercadolivre.js';
import { buscarAmazon, buscarShopee, buscarLojaOficial } from './sources/indisponivel.js';

const FONTES_PRIORITARIAS = [
  'Mercado Livre',
  'Amazon',
  'Shopee',
  'Loja oficial'
];

function mediana(valores) {
  const ordenados = [...valores].sort((a, b) => a - b);
  if (!ordenados.length) return null;
  const meio = Math.floor(ordenados.length / 2);
  return ordenados.length % 2
    ? ordenados[meio]
    : (ordenados[meio - 1] + ordenados[meio]) / 2;
}

function validarCandidato(candidato) {
  return candidato &&
    typeof candidato.preco === 'number' &&
    Number.isFinite(candidato.preco) &&
    candidato.preco > 0 &&
    typeof candidato.url === 'string' &&
    candidato.url.length > 0;
}

export function escolherPreco(candidatos) {
  const validos = candidatos.filter(validarCandidato);
  if (!validos.length) {
    return { aprovado: false, preco: null, motivo: 'Nenhum preço confiável encontrado.', candidatos: [] };
  }

  const precos = validos.map(c => c.preco);
  const med = mediana(precos);

  // Proteção: evita escolher automaticamente um valor muito fora do conjunto.
  const dentroDaFaixa = validos.filter(c => {
    if (validos.length === 1) return true;
    return c.preco >= med * 0.65 && c.preco <= med * 1.35;
  });

  if (!dentroDaFaixa.length) {
    return { aprovado: false, preco: null, motivo: 'Os preços encontrados ficaram fora da faixa de validação.', candidatos: validos };
  }

  // Com uma única fonte, o preço é aceito somente se a correspondência já tiver sido validada pelo adaptador.
  // Com várias fontes, usamos a mediana dos valores dentro da faixa.
  const preco = mediana(dentroDaFaixa.map(c => c.preco));

  const escolhido = [...dentroDaFaixa].sort((a, b) => {
    const pa = FONTES_PRIORITARIAS.indexOf(a.fonte);
    const pb = FONTES_PRIORITARIAS.indexOf(b.fonte);
    return pa - pb;
  })[0];

  return {
    aprovado: true,
    preco: Number(preco.toFixed(2)),
    fontePrincipal: escolhido.fonte,
    candidatos: dentroDaFaixa,
    motivo: 'Preço aprovado pelas regras de validação.'
  };
}

export async function coletarPrecos(produto) {
  const resultados = [];

  if (produto.fontes?.mercadolivre) {
    try {
      resultados.push(...await buscarMercadoLivre(produto));
    } catch (erro) {
      resultados.push({ fonte: 'Mercado Livre', erro: erro.message });
    }
  }

  if (produto.fontes?.amazon) {
    resultados.push(...await buscarAmazon(produto));
  }

  if (produto.fontes?.shopee) {
    resultados.push(...await buscarShopee(produto));
  }

  if (produto.fontes?.oficial) {
    resultados.push(...await buscarLojaOficial(produto));
  }

  return resultados;
}
