const BASE_URL = 'https://api.mercadolibre.com/sites/MLB/search';

function normalizar(texto = '') {
  return texto
    .normalize('NFD')
    .replace(/[\u0300-\u036f]/g, '')
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, ' ')
    .trim();
}

function tokens(texto) {
  return new Set(normalizar(texto).split(/\s+/).filter(Boolean));
}

function similaridade(produto, titulo) {
  const alvo = tokens(`${produto.marca} ${produto.modelo} ${produto.variacao}`);
  const candidato = tokens(titulo);
  if (!alvo.size || !candidato.size) return 0;

  let acertos = 0;
  for (const token of alvo) {
    if (candidato.has(token)) acertos++;
  }
  return acertos / alvo.size;
}

export async function buscarMercadoLivre(produto) {
  const query = `${produto.marca} ${produto.modelo} ${produto.variacao || ''}`.trim();
  const url = `${BASE_URL}?q=${encodeURIComponent(query)}&limit=20&sort=price_asc`;

  const headers = { Accept: 'application/json' };
  if (process.env.MERCADOLIVRE_ACCESS_TOKEN) {
    headers.Authorization = `Bearer ${process.env.MERCADOLIVRE_ACCESS_TOKEN}`;
  }

  const response = await fetch(url, { headers });
  if (!response.ok) {
    throw new Error(`Mercado Livre respondeu HTTP ${response.status}`);
  }

  const data = await response.json();
  const resultados = Array.isArray(data.results) ? data.results : [];

  return resultados
    .map(item => ({
      fonte: 'Mercado Livre',
      titulo: item.title || '',
      preco: Number(item.price),
      moeda: item.currency_id || 'BRL',
      url: item.permalink || '',
      vendedor: item.seller?.nickname || '',
      similaridade: similaridade(produto, item.title || '')
    }))
    .filter(item => Number.isFinite(item.preco) && item.preco > 0 && item.similaridade >= 0.60)
    .slice(0, 10);
}
