/**
 * Adaptadores que serão ligados depois às APIs/integrações permitidas de cada fonte.
 * Eles NÃO inventam preços. Enquanto não houver integração configurada, retornam [].
 */

export async function buscarAmazon() {
  return [];
}

export async function buscarShopee() {
  return [];
}

export async function buscarLojaOficial() {
  return [];
}
